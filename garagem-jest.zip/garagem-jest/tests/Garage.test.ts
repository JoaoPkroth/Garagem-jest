import {Garage} from "../src/Garage";
import {Car} from "../src/Car";

describe("Teste 1 - Criar um carro", () => {
    test("Criando Volkswagen Gol", () => {
        // Arrange & Act
        const car = new Car("Volkswagen", "Gol", 2010);

        // Assert
        expect(car.getBrand()).toBe("Volkswagen");
        expect(car.getModel()).toBe("Gol");
        expect(car.getYear()).toBe(2010);
    })
})

describe("Teste 2 - Verificar o estado inicial de stored", () => {
    test("Stored começa como false", () => {
        // Arrange & Act
        const car = new Car("Volkswagen", "Gol", 2010);

        // Assert
        expect(car.getStored()).toBe(false);
    })
})

describe("Teste 3 - Alterar stored para true", () => {
    test("Alterando para true", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);

        // Act
        car.setStored(true);

        // Assert
        expect(car.getStored()).toBe(true);
    })
})

describe("Teste 4 - Alterar stored para false", () => {
    test("Alterando para true e depois para false", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);

        // Act
        car.setStored(true);
        car.setStored(false);

        // Assert
        expect(car.getStored()).toBe(false);
    })
})

describe("Teste 5 - Adicionar um carro", () => {
    test("Garagem com 1 carro", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const garagem = new Garage();

        // Act
        garagem.addCar(car);

        // Assert
        expect(garagem.getCarCount()).toBe(1);
    })
})

describe("Teste 6 - Verificar stored após adicionar", () => {
    test("Stored passa para true", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const garagem = new Garage();

        // Act
        garagem.addCar(car);

        // Assert
        expect(car.getStored()).toBe(true);
    })
})

describe("Teste 7 - Adicionar vários carros", () => {
    test("Garagem com 3 carros", () => {
        // Arrange
        const garagem = new Garage();
        const car = new Car("Volkswagen", "Gol", 2010);
        const car2 = new Car("Volkswagen", "Polo", 2018);
        const car3 = new Car("Volkswagen", "Fox", 2008);

        // Act
        garagem.addCar(car);
        garagem.addCar(car2);
        garagem.addCar(car3);

        // Assert
        expect(garagem.getCarCount()).toBe(3);
    })
})

describe("Teste 8 - Remover um carro", () => {
    test("Garagem fica vazia", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const garagem = new Garage();
        garagem.addCar(car);

        // Act
        garagem.removeCar(car);

        // Assert
        expect(garagem.getCarCount()).toBe(0);
    })
})

describe("Teste 9 - Verificar stored após remover", () => {
    test("Stored passa para false", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const garagem = new Garage();
        garagem.addCar(car);

        // Act
        garagem.removeCar(car);

        // Assert
        expect(car.getStored()).toBe(false);
    })
})

describe("Teste 10 - Procurar um carro existente", () => {
    test("Encontra o carro pelo modelo", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const garagem = new Garage();
        garagem.addCar(car);

        // Act
        const found = garagem.findCarByModel("Gol");

        // Assert
        expect(found).toBe(car);
    })
})

describe("Teste 11 - Procurar um carro inexistente", () => {
    test("Retorna undefined", () => {
        // Arrange
        const garagem = new Garage();
        garagem.addCar(new Car("Volkswagen", "Gol", 2010));

        // Act
        const found = garagem.findCarByModel("Fox");

        // Assert
        expect(found).toBe(undefined);
    })
})

describe("Teste 12 - Não permitir carros duplicados", () => {
    test("Lança erro ao adicionar o mesmo carro duas vezes", () => {
        // Arrange
        const garagem = new Garage();
        garagem.addCar(new Car("Volkswagen", "Gol", 2010));
        const duplicado = new Car("Volkswagen", "Gol", 2010);

        // Act & Assert
        expect(() => garagem.addCar(duplicado)).toThrow();
    })
})

describe("Teste 13 - Verificar a marca do carro encontrado", () => {
    test("Marca correta", () => {
        // Arrange
        const garagem = new Garage();
        garagem.addCar(new Car("Volkswagen", "Polo", 2018));

        // Act
        const brand = garagem.findCarByModel("Polo")?.getBrand();

        // Assert
        expect(brand).toBe("Volkswagen");
    })
})

describe("Teste 14 - Verificar o ano do carro encontrado", () => {
    test("Ano correto", () => {
        // Arrange
        const garagem = new Garage();
        garagem.addCar(new Car("Volkswagen", "Polo", 2018));

        // Act
        const year = garagem.findCarByModel("Polo")?.getYear();

        // Assert
        expect(year).toBe(2018);
    })
})

describe("Teste 15 - Remover um carro entre vários", () => {
    test("Os outros dois continuam na garagem", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const car2 = new Car("Volkswagen", "Polo", 2018);
        const car3 = new Car("Volkswagen", "Fox", 2008);
        const garagem = new Garage();
        garagem.addCar(car);
        garagem.addCar(car2);
        garagem.addCar(car3);

        // Act
        garagem.removeCar(car3);

        // Assert
        expect(garagem.getCarCount()).toBe(2);
        expect(garagem.findCarByModel("Gol")).toBe(car);
        expect(garagem.findCarByModel("Polo")).toBe(car2);
    })
})

describe("Teste 16 - Verificar os estados após remover um carro", () => {
    test("Removido false, os outros true", () => {
        // Arrange
        const car = new Car("Volkswagen", "Gol", 2010);
        const car2 = new Car("Volkswagen", "Polo", 2018);
        const car3 = new Car("Volkswagen", "Fox", 2008);
        const garagem = new Garage();
        garagem.addCar(car);
        garagem.addCar(car2);
        garagem.addCar(car3);

        // Act
        garagem.removeCar(car3);

        // Assert
        expect(car.getStored()).toBe(true);
        expect(car2.getStored()).toBe(true);
        expect(car3.getStored()).toBe(false);
    })
})

describe("Desafio 1 - Carros de uma marca", () => {
    test("Retorna todos os carros da marca", () => {
        // Arrange
        const corolla = new Car("Toyota", "Corolla", 2025);
        const yaris = new Car("Toyota", "Yaris", 2024);
        const garagem = new Garage();
        garagem.addCar(corolla);
        garagem.addCar(yaris);
        garagem.addCar(new Car("Ford", "Mustang", 2024));
        garagem.addCar(new Car("Honda", "Civic", 2023));

        // Act
        const toyotas = garagem.getCarsByBrand("Toyota");

        // Assert
        expect(toyotas.length).toBe(2);
        expect(toyotas).toContain(corolla);
        expect(toyotas).toContain(yaris);
    })
})

describe("Desafio 2 - Marca inexistente", () => {
    test("Retorna lista vazia", () => {
        // Arrange
        const garagem = new Garage();
        garagem.addCar(new Car("Toyota", "Corolla", 2025));

        // Act
        const fiats = garagem.getCarsByBrand("Fiat");

        // Assert
        expect(fiats.length).toBe(0);
    })
})