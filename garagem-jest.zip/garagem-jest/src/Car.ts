export class Car {
  private brand: string;
  private model: string;
  private year: number;
  private stored: boolean;

  constructor(brand: string, model: string, year: number) {
    this.brand = brand;
    this.model = model;
    this.year = year;
    this.stored = false;
  }

  getBrand(): string { return this.brand; }
  getModel(): string { return this.model; }
  getYear(): number { return this.year; }
  getStored(): boolean { return this.stored; }
  setStored(value: boolean): void { this.stored = value; }
}