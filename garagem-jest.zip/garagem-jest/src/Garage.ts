import { Car } from "./Car";

export class Garage {
  protected garage: Car[];

  constructor(garage: Car[] = []) {
    this.garage = garage;
  }

  public addCar(newCar: Car) {
    const duplicated = this.garage.some(
      (car) =>
        car.getBrand() === newCar.getBrand() &&
        car.getModel() === newCar.getModel() &&
        car.getYear() === newCar.getYear()
    );

    if (duplicated) {
      throw new Error("Car already exists in the garage");
    }

    this.garage.push(newCar);
    newCar.setStored(true);
  }

  public removeCar(car: Car) {
    const index = this.garage.indexOf(car);
    if (index !== -1) {
      this.garage.splice(index, 1);
      car.setStored(false);
    }
  }

  public getCarCount() {
    return this.garage.length;
  }

  public findCarByModel(model: string): Car | undefined {
    return this.garage.find((car) => car.getModel() === model);
  }

  public getCarsByBrand(brand: string): Car[] {
    return this.garage.filter((car) => car.getBrand() === brand);
  }
}